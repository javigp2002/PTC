import R1 as r1
import R2 as r2
import R3 as r3
import R4 as r4
import R5 as r5
print("Se han ejecutado todos los archivos")